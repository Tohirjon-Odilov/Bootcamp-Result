﻿namespace _22_lesson_http_client.Homework
{
    public class MovieMadel
    {
        public string Title { get; set; } = String.Empty;
        public string Year { get; set; } = String.Empty;
        public string imdbID { get; set; } = String.Empty;
        public string Type {  get; set; } = String.Empty;
        public string Poster {  get; set; } = String.Empty;
    }
}

/*
 {
      "Title": "Italian Spiderman",
      "Year": "2007",
      "imdbID": "tt2705436",
      "Type": "movie",
      "Poster": "https://m.media-amazon.com/images/M/MV5BZWQxMjcwNjItZjI0ZC00ZTc4LWIwMzItM2Q0YTZhNzI3NzdlXkEyXkFqcGdeQXVyMTA0MTM5NjI2._V1_SX300.jpg"
}
 */