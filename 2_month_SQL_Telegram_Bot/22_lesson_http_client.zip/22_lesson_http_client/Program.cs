﻿// key 6577cabc
using _22_lesson_http_client.Homework;

//NationalBankUzbekistan NBU = new NationalBankUzbekistan();
Server omdbapi = new Server();
