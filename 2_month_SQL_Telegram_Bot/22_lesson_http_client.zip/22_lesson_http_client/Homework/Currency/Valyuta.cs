﻿namespace _22_lesson_http_client.Homework.Currency
{
    public class Valyuta
    {
        public string title { get; set; } = String.Empty;
        public string code { get; set; } = String.Empty;
        public string cb_price { get; set; } = String.Empty;
        public string nbu_buy_price { get; set; } = String.Empty;
        public string nbu_cell_price { get; set; } = String.Empty;
        public string date { get; set; } = String.Empty;
    }
}

/* {
        "title": "?????? ???",
        "code": "AED",
        "cb_price": "3361.32",
        "nbu_buy_price": "",
        "nbu_cell_price": "",
        "date": "11.01.2024"
}*/
