﻿namespace _22_lesson_http_client.Homework
{
    public class DataInfoMadel
    {
        public string Title { get; set; } = String.Empty;
        public string Year { get; set; } = String.Empty;
        public string Rated { get; set; } = String.Empty;
        public string Released { get; set; } = String.Empty;
        public string Runtime { get; set; } = String.Empty;
        public string Genre { get; set; } = String.Empty;
        public string Director { get; set; } = String.Empty;
        public string Writer { get; set; } = String.Empty;
        public string Actors { get; set; } = String.Empty;
        public string Plot { get; set; } = String.Empty;
        public string Language { get; set; } = String.Empty;
        public string Country { get; set; } = String.Empty;
        public string Awards { get; set; } = String.Empty;
        public string Poster { get; set; } = String.Empty;
        public string Metascore { get; set; } = String.Empty;
        public string imdbRating { get; set; } = String.Empty;
        public string imdbVotes { get; set; } = String.Empty;
        public string imdbID { get; set; } = String.Empty;
        public string Type { get; set; } = String.Empty;
        public string totalSeasons { get; set; } = String.Empty;
        public string Response { get; set; } = String.Empty;
    }
}
